library("testthat")
library("qdapTools")


test_check("qdapTools")