Trim <-
function (x) gsub("^\\s+|\\s+$", "", x)
