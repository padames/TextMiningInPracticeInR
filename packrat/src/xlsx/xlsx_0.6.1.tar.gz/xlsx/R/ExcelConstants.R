# This file defines Excel specific constants

.EXCEL_LIMIT_MAX_CHARS_IN_CELL <- 32767
